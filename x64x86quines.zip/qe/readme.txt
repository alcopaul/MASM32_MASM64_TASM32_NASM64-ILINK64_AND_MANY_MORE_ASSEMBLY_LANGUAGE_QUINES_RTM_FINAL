assembled and linked without errors - 7/2/2025

ewdk version : Windows 11, version 24H2 EWDK (released June, 2025) with Visual Studio Buildtools 17.11.4

tasm32
ilink32
bcc64

from Embarcadero® C++Builder 12 Version 29.0.51961.7529

nasm version 2.16.03 compiled on Apr 17 2024

F:\EWDK>launchbuildenv x86
**********************************************************************
** Enterprise Windows Driver Kit (WDK) build environment
** Version ge_release_svc_prod3.26100.4202
**********************************************************************
** Visual Studio 2022 Developer Command Prompt v17.11.4
** Copyright (c) 2022 Microsoft Corporation
**********************************************************************
F:\EWDK>launchbuildenv amd64
**********************************************************************
** Enterprise Windows Driver Kit (WDK) build environment
** Version ge_release_svc_prod3.26100.4202
**********************************************************************
** Visual Studio 2022 Developer Command Prompt v17.11.4
** Copyright (c) 2022 Microsoft Corporation
**********************************************************************
F:\EWDK>


~ alCoPaUL, beth GviLLErMo [GIMO]
7/2/2025

